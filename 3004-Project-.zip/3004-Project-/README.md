# 3004-Project- Group Number: 75

# Assigned TA : Monica Diep

# group members: 
Ayomide Awonaya, 
Abdel Qayyim Maazou Yahaya, 
faramade Odusanya 

# Resposibilities 
  Ayomide Awonaya - code for header files and source files as well as building the tracebility matrix, 
  Abdel Qayyim Maazou Yahaya -  additional class functionalities and GUI, 
  Faramade Odusanya - use cases, UML, sequence diagrams and state diagrams 

